#Desenvolva um programa que leia um número inteiro qualquer e que apresente o número informado, seguido do seu antecessor e do seu sucessor

numero = int(input("Digite um número  que seja inteiro: "))
antecessor = numero - 1
sucessor = numero + 1

print("O número informado é:", numero)
print("O seu antecessor é:", antecessor)
print("O seu sucessor é:", sucessor)
