#Desenvolva um programa que pergunte o seu nome e, ao teclar Enter, apresente uma saudação personalizada com seu nome.

nome = input (str("Qual é o seu nome?" ))  # pede ao usuário para inserir o seu nome
print("Olá, " + nome + " Tudo bem com você?")  # apresenta uma saudação personalizada com o nome do usuário

