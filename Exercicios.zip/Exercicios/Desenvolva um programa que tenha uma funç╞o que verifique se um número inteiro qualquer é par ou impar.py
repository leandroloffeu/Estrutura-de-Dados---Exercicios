#Desenvolva um programa que tenha uma função que verifique se um número inteiro qualquer é par ou impar

def par_impar(numero):
    if numero % 2 == 0:
        print(f"O número {numero} é par.")
    else:
        print(f"O número {numero} é ímpar.")

par_impar(10)
par_impar(7) 
par_impar(0) 
par_impar(-5)

